<?php
if (!defined('_ECRIRE_INC_VERSION')) {
	return;
}

$GLOBALS[$GLOBALS['idx_lang']] = array(

	// A
	'annuler' => 'Cancel',

	// B
	'bouton_supprimer' => 'Delete',

	// E
	
	'explication_exec_clesite' => 'Public key delivred by google wich identify your website.',
    'explication_exec_cleprive' => 'Secret key given by',

	

	// L
	'label_exec_cleprive' => 'Write your secret key',
	'label_exec_clesite' => 'Write your website key',
	'legend_editer_cleprive' => 'Change your secret key',
	'legend_editer_clesite' => 'Change your website key',
	'lien_console_captcha' => 'https://www.google.com/recaptcha/admin',

	// T
	'texte_console_captcha' => 'console google',
	'titre_config_cryptocaptcha' => 'Configure cryptocaptcha',
	'titre_cryptocaptcha' => 'CryptoCaptcha',

	// U
	'update_impossible' => 'update failed',

	// V
	'veuillez_patienter' => 'it will take a moment...'
);

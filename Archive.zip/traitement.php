<?php



function traitementCaptcha(){


	echo 'coucou';
}